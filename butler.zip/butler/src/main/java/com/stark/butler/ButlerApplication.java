package com.stark.butler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ButlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ButlerApplication.class, args);
	}

}
