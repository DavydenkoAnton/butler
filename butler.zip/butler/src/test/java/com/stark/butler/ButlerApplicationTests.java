package com.stark.butler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ButlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
